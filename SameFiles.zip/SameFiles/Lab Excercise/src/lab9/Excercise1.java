package lab9;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;

public class Excercise1 
{
	ArrayList getValues(HashMap h)
	{
		Collection values = h.values();
		ArrayList lists = new ArrayList(values);
		return lists;
	}
	public static void main(String [] args)
	{
		Scanner keyboard = new Scanner(System.in);
		Excercise1 a = new Excercise1();
		Maps a1 = new Maps(1,"hello");
		Maps a2 = new Maps(2,"hai");
		HashMap<Integer,Maps> h = new HashMap<Integer,Maps>();
		h.put(1,a1);
		h.put(2,a2);
		System.out.println(a.getValues(h));
	}
}

class Maps
{
	int id;
	String name;
	Maps(int eid,String ename)
	{
		id = eid;
		name = ename;
	}
	public String toString()
	{
		return "Id:" +id+" " +"name:" + name;
	}
}