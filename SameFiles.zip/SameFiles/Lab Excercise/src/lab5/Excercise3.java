package lab5;
import java.util.*;

public class Excercise3 
{
	public static void main(String [] args)
	{
		Scanner keyboard = new Scanner(System.in);
		int no = keyboard.nextInt();
		Prime p = new Prime();
		p.prime(no);
		
	}
}

class Prime
{
	void prime(int n)
	{
		for (int i=2;i<=n;i++)
		{
			int p=0;
			for(int j=2;j<i;j++)
			{
				if(i%j==0)
					p=1;
			}
			if (p==0)
				System.out.println(i);
		}
	}
}
