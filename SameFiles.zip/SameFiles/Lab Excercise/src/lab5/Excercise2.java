package lab5;

import java.util.*;

public class Excercise2 
{
	public static void main(String [] args)
	{
		Scanner keyboard = new Scanner(System.in);
		int a = keyboard.nextInt();
		Fib f = new Fib();
		f.fib(a);
		
	}
}


class Fib
{
	void fib(int n)
	{
		int a=1,b=1;
		System.out.printf("%d %d ",a,b);
		for(int i=3;i<=n;i++)
		{
			int c = a+b;
			System.out.print(c + " ");
			a=b;
			b=c;		
		}
	}
}