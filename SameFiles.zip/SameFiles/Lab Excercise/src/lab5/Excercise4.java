package lab5;
import java.util.*;
public class Excercise4 
{
	public static void main(String [] args)
	{
		Scanner keyboard = new Scanner(System.in);
		String firstname = keyboard.nextLine();
		String lastname = keyboard.nextLine();
		//String firstname = null;
		//String lastname = null;
		try
		{
			if(firstname == null && lastname == null)
				System.out.println("firstname and lastname should not be left empty");
			else
				System.out.println("Firstname: "+firstname+"Lastname: "+lastname);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
