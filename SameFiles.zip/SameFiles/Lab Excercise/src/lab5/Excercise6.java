package lab5;

import java.util.*;

public class Excercise6 
{
	public static void main(String [] args)
	{
		Scanner keyboard = new Scanner(System.in);
		int salary = keyboard.nextInt();
		try 
		{
			if(salary < 3000)
			{
				throw new EmployeeException();
			}
			else
				System.out.println("Salary: "+salary);
		}
		catch(Exception a)
		{
			System.out.println("Exception error");
		}
	}
}
class EmployeeException extends RuntimeException
{
	EmployeeException()
	{
		System.out.println("Salary should be above 3000");
	}
}