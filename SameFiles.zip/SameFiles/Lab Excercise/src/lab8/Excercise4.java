package lab8;
import java.util.*;
import java.io.File;

public class Excercise4 
{
	public static void main(String [] args)
	{
		Scanner keyboard = new Scanner(System.in);
		String s = keyboard.nextLine();
		File f = new File(s);
		System.out.println("File Name: "+f.getName());
		System.out.println("File is readable or not: "+f.canRead());
		System.out.println("File is writeable or not: "+f.canWrite());
		System.out.println("File exists or not: "+f.exists());
		System.out.println("File length in bytes: "+f.length());
	}
}
