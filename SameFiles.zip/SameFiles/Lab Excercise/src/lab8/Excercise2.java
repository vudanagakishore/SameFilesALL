package lab8;
import java.io.IOException;
import java.io.RandomAccessFile;

public class Excercise2 
{
	public static void main(String [] args) throws Exception
	{
		File keyboard =  new File();
		keyboard.raf();
	}
}

class File
{
	public void raf() throws IOException
	{
		try {
			RandomAccessFile rafobj = new RandomAccessFile("C:\\filename/filename.txt","r");
			String s;
			int number=0;
			while((s=rafobj.readLine())!=null)
				{
				number++;
				 System.out.println(number+"."+s);
				}
		    }
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}