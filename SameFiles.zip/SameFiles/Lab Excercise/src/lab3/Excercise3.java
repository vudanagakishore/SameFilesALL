package lab3;
import java.util.*;

public class Excercise3 
{
	public static void main(String [] args)
	{
		int array1[] = new int[4];
		int array2[] = new int[4];
		array1[0] = 1;
		array1[1] = 2;
		array1[2] = 3;
		array1[3] = 4;
		SortedArray keyboard = new SortedArray();
		array2 = keyboard.sortedArray(array1);
		System.out.println(Arrays.toString(array2));
		
	}
}


class SortedArray
{
	int[] sortedArray(int a1[])
	{
		int length = a1.length;
		int a2[] = new int[length];
		int j=0;
		int temp;
		for(int i=a1.length-1;i>=0;i--)
		{
			a2[j] = a1[i];
			j++;
		}
		for(int k=0;k<length;k++)
		{
			for(int l=k+1;l<length;l++)
			{
				if (a2[k] > a2[l])
				{
					temp = a2[k];
					a2[k] = a2[l];
					a2[l] = temp;
				}
			}
		}
		return a2;
	}
}