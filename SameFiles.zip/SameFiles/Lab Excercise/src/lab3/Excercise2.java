package lab3;

import java.util.*;
public class Excercise2 
{
	public static void main(String [] args)
	{
		Scanner keyboard = new Scanner(System.in);
		Alphabet kb = new Alphabet();
		int no = keyboard.nextInt();
		String arr[] = new String[no];
		for(int i=0;i<no;i++)
		{
			arr[i] = keyboard.next().toLowerCase();
		
		}
		kb.alphabet(arr);
	}
}

class Alphabet
{
	int i=0;
	public void alphabet(String[] arr)
	{
		int length = arr.length;
		Arrays.sort(arr);
		System.out.println(Arrays.toString(arr));
		if(length%2 !=0)
		{
			for(int i=0; i<(length/2)+1;i++)
			{
				arr[i] = arr[i].toUpperCase();
			}
			for(int i=(length/2)+1; i<length;i++)
			{
				arr[i] = arr[i].toLowerCase();
			}
		}
		else 
		{
			for(int i=0; i<(length/2);i++)
			{
				arr[i] = arr[i].toUpperCase();
			}
			for(int i=(length/2); i<length;i++)
			{
				arr[i] = arr[i].toLowerCase();
			}
		}
		System.out.println(Arrays.toString(arr));
	}
	
	}
