package lab3;
import java.util.*;
public class Excercise4 
{
	public static void main(String [] args)
	{
		Scanner keyboard = new Scanner(System.in);
		char ch[] = new char[20];
		ch = keyboard.next().toCharArray();
		int length1 = ch.length;
		int count = 0;
		int flag=0;
		for(int k=0;k<length1;k++)
		{
			count = 0;
			for(int l=0;l<length1;l++)
			{
				if (ch[l] == ch[k])
					count++;
				for(int m=0;m<k;m++)
				{	
					if(ch[m]==ch[k])
						flag=1;
				}
			}
				if(flag==0)
					System.out.println(ch[k]+" "+ count);
			
					
			}
		}
}

