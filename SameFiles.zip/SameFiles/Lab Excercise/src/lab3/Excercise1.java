package lab3;
import java.util.*;
public class Excercise1 
{
	public static void main(String [] args)
	{
		int array[] = { 11,3,22,34};
		SecondLarge keyboard = new SecondLarge();
		int result = keyboard.secondLargest(array);
		System.out.println(result);
			
	}
}


class SecondLarge
{
	int no =  4;
	int temp;
	int secondLargest(int a[])
	{
		for (int i=0;i<no;i++)
		{
			for(int j=i+1;j<no;j++)
			{
				if(a[i]>a[j])
				{
					temp = a[i];
					a[i] = a[j];
					a[j] = temp;
				}
			}
		}
		return a[1];
	}
}