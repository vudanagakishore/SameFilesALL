package lab13;
import java.util.*;
public class Excercise5 
{
	public static void main(String [] args)
	{
		Scanner keyboard = new Scanner(System.in);
		int number = keyboard.nextInt();
		Factorial f =new Factorial();
		Factorial1 fact = f::factorial;
		int result = fact.fact(number);
		System.out.println(result);
	}
	
}


class Factorial
{
	int factorial(int a)
	{
		int fact=1;
		for(int i=1;i<=a;i++)
		{
			fact = fact*i;
		}
		return fact;
	}
}

interface Factorial1
{
	int fact(int x);
}