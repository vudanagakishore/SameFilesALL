package lab13;
import java.util.*;
public class Excercise2 
{
	public static void main(String [] args)
	{
		Scanner keyboard = new Scanner(System.in);
		String s = keyboard.nextLine();
		Space s1 = (a) -> giveSpace(a);
		System.out.println(s1.space(s));
	}
	
	static String giveSpace(String s2)
	{
		String a=" ";
		for(int i=0;i<s2.length();i++)
		{
			a = a+s2.charAt(i)+" ";
		}
		return a;
	}
}

interface Space
{
	String space(String s);
}