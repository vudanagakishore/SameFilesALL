package lab13;
import java.util.*;

public class Excercise3 
{
	public static void main(String [] args)
	{
		Scanner keyboard = new Scanner(System.in);
		String username = keyboard.nextLine();//username
		String password = keyboard.nextLine();//password
		Usernamepassword up = (a,b) -> Authentication(a,b);
		if(up.Usernamepassword(username,password))
		{
			System.out.println("Login Successful");
		}
		else
		{
			System.out.println("Login UnSuccessful");
		}
	}
	static boolean Authentication(String a, String b)
	{
		boolean value = false;
		String username = "hello";
		String password = "hello";
		if(a.equals(username)&&b.equals(password))
		{
			return true;
		}
		return value;
	}
}

interface Usernamepassword
{
	boolean Usernamepassword(String username, String password);
}
