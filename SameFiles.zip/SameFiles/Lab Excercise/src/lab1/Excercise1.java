package lab1;
import java.util.*;
public class Excercise1 
{
	public static void main(String[] arg)
	{
		
		Scanner keyboard = new Scanner(System.in);
		int a = keyboard.nextInt();
		CaluclateSum s = new CaluclateSum();
		s.caluclatesum(a);
	}
}


class CaluclateSum
{
	void caluclatesum(int n)
	{   
		int i;
		int sum = 0;
		for(i=1;i<=n;i++)
		{
			if(i%3==0||i%5==0)
			{
				sum=sum+i;
			}
			
		}
			System.out.println(sum);
			
	}
}