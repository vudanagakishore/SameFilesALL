package lab1;
import java.util.*;
public class Excercise2 {
	public static void main(String[] args)
	{
		Scanner keyboard = new Scanner(System.in);
		int a = keyboard.nextInt();
		CalculateDifference s = new CalculateDifference();
		s.calculatedifference(a);
	}
}



class CalculateDifference
{
	void calculatedifference(int n)
	{
		int l=0,k=0;
		int d;
		for(int i=1;i<=n;i++)
		{
			l = l + i*i; 
		}
		for(int i=1;i<=n;i++)
		{
			k = k +i; 
		}
		k = k*k;
		d = k-l;
		System.out.println(d);
	}  
}