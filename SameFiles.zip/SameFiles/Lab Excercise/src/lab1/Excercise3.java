package lab1;
import java.util.*;
public class Excercise3 
{
	public static void main(String[] args)
	{
		Scanner keyboard = new Scanner(System.in);
		int a = keyboard.nextInt();
		if(checkNumber(a))
			System.out.println("power of 2");
		else
			System.out.println("not power of 2");
	}

 static boolean checkNumber(int number)
	{
		while(number>1)
		{
			if(number%2!=0)
			{
				return false;
			}
			number =number/2;
		}return true;
	}
}
